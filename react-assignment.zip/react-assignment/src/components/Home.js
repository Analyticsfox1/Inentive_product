import React, { Component } from 'react';
import { Link } from "react-router-dom";

class Home extends Component {
	render() {
		return (
			<div>
				<h2 className="text-center mt-5"><strong> Welcome to Home Page </strong></h2>
				<div className="mt-4 d-flex justify-content-center">
					<Link to="/login">	<button type="button" className="btn btn-primary btn-rounded">Login Now</button> </Link>
				</div>
			</div>
		)
	}
}

export default Home