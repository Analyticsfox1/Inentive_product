import React, { Component } from 'react'

class Dashboard extends Component {

	state = {
		isToggle: false
	}

	_removeStorage = () => {
		sessionStorage.removeItem('userData');
		this.props.history.push('/login');
	}

	toggleClick = (e) => {
		e.preventDefault();
		if (this.state.isToggle) {
			this.setState({
				isToggle: false,
			})
		}
		else {
			this.setState({
				isToggle: true,
			})
		}
	}

	render() {
		return (

			<div className={"d-flex dashboard-page" + (this.state.isToggle ? ' toggled' : ' ')} id="wrapper">
				<div className="bg-light border-right" id="sidebar-wrapper">
					<div className="sidebar-heading text-white bg-dark-blue">Brand</div>
					<div className="list-group list-group-flush">
						<a href="#" className="list-group-item list-group-item-action text-white bg-blue"><i class="fas fa-tachometer-alt"></i>&nbsp;

My Dashboard</a>
						<a href="#" className="list-group-item list-group-item-action bg-light">Active Cases</a>
						<a href="#" className="list-group-item list-group-item-action bg-light"><i class="fas fa-money" aria-hidden="true"></i>
							Payouyt</a>
						<a href="#" className="list-group-item list-group-item-action bg-light"><i class="fas fa-file-text" aria-hidden="true"></i>
							Invoice Generator</a>
						<a href="#" className="list-group-item list-group-item-action bg-light">
							Payment Status</a>
					</div>
				</div>
				<div id="page-content-wrapper">

					<nav className="navbar navbar-expand-lg navbar-light bg-dark-blue border-bottom">
						<a className="text-white" onClick={this.toggleClick} id="menu-toggle"><i className="fas fa-bars"></i></a>

						<button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							<span className="navbar-toggler-icon"></span>
						</button>

						<div className="collapse navbar-collapse" id="navbarSupportedContent">
							<ul className="navbar-nav ml-auto mt-2 mt-lg-0">

								<li className="nav-item dropdown">
									<a className="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										DSA1
              		</a>
									<div className="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
										<a className="dropdown-item" onClick={this._removeStorage}>Logout</a>
									</div>
								</li>
							</ul>
						</div>
					</nav>
					<div className="container">
						<div className="row mt-3">
							<div className="col-sm-6">
								<div class="card bg-white">
									<div className="card-header text-center text-underline">Disbursed</div>
									<div className="card-body pb-0">
										<div className="d-flex justify-content-between  align-content-center">
											<p className="text-center">Total sales <br />
												<span>20,00,000</span>
											</p>
											<p className="text-center"> No. of Cases  <br />
												<span>4</span>
											</p>
										</div>
										<div className="d-flex justify-content-center mt-3  align-content-center">
											<p className="text-center">Commision Payble<br />
												<span>xxxxxx</span>
											</p>
										</div>
									</div>
								</div>
							</div>
							<div className="col-sm-6">
								<div class="card bg-white">
									<div className="card-header text-center text-underline ">In Progress</div>
									<div className="card-body pb-0">
										<div className="d-flex justify-content-between  align-content-center">
											<p className="text-center">Totla sales <br />
												<span>10,00,000</span>
											</p>
											<p className="text-center"> No. of Case  <br />
												<span>1</span>
											</p>
										</div>
										<div className="d-flex justify-content-center mt-3  align-content-center">
											<p className="text-center">Commision Due<br />
												<span>xxxxxx</span>
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div className="row mt-5">
							<div className="col-sm-6 offset-md-3">
								<div class="card bg-white">
									<div className="card-header text-center text-underline">Payout Slabs</div>
									<div className="card-body pb-0">
										<div className="d-flex justify-content-between  align-content-center">
											<img className="text-center" style={{ height: '200px', width: '350px' }} src="https://www.iciciprulife.com/content/icici-prudential-life-insurance/ulip-plans/icicipru-lifetime-classic/_jcr_content/contentpar/container_fullwidth/container-fullwidth-parsys/gridsystem_424694496/column-2/image.img.jpg/1495535401737.jpg" />
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		)
	}
}

export default Dashboard