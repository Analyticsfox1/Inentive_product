import React, { Component } from 'react'
import { Link } from "react-router-dom";

class Login extends Component {

	constructor() {
		super();
		this.state = {
			username: '',
			password: '',
			isInvalid: false,
			errors: {
				usernameError: null,
				passwordError: null
			}
		}
	}

	componentWillMount = () => {
		const active = sessionStorage.getItem('userData') ? true : false;
		this._LoggedIn(active)
	}

	_LoggedIn = (active) => {
		if (active) {
			this.props.history.push('/dashboard');
		}
	}

	handleSubmit = () => {
		const user = { username: this.state.username, password: this.state.password }
		this.validateUser(user);
	}

	validateUser = (user) => {
		const { username, password } = this.state;
		if (username == 'DSA1' && password == 'DSA@12345') {
			sessionStorage.setItem("userData", JSON.stringify(user));
			this.props.history.push('/dashboard');
		}
		else {
			this.setState({
				isInvalid: true
			})
		}
	}

	handleValidate = (e) => {
		const { errors } = this.state;
		let name = e.target.name;
		let value = e.target.value;
		if (value === "" || value === null || value === undefined) {
			this.setState({ errors: { ...errors, [name + 'Error']: true } });
		}
		else {
			this.setState({ errors: { ...errors, [name + 'Error']: false } });
		}
	}

	handleChange = (e) => {
		this.setState({
			[e.target.name]: e.target.value
		})
	}

	render() {
		const { username, password, errors, isInvalid } = this.state;
		return (
			<div className="login-container offset-md-2">
				<div className="d-flex justify-content-center h-100">
					<div className="card">
						<div className="card-header">
							<h4 className="text-white">LOGIN</h4>
							<hr />
							<h6 className="text-white"> Access your account </h6>
						</div>
						<div className="card-body login-form">
							{
								isInvalid &&
								<div className="alert alert-danger" role="alert">
									Invalid Username or Password...!!!
						</div>
							}
							<div className="input-group form-group">
								<div className="input-group-prepend">
									<span className="input-group-text"><i className="fas fa-user"></i></span>
								</div>
								<input
									type="text"
									className="form-control"
									name="username"
									value={username}
									onChange={this.handleChange}
									onBlur={this.handleValidate}
									placeholder="Username" />
							</div>
							{
								errors.usernameError &&
								<span style={{ color: 'red', fontSize: '15px' }}>Please enter username</span>
							}
							<div className="input-group form-group">
								<div className="input-group-prepend">
									<span className="input-group-text"><i className="fas fa-key"></i></span>
								</div>
								<input
									type="password"
									className="form-control"
									name="password"
									value={password}
									onChange={this.handleChange}
									onBlur={this.handleValidate}
									placeholder="Password" />
							</div>
							{
								errors.passwordError &&
								<span style={{ color: 'red', fontSize: '15px' }}>Please enter password</span>
							}
							<div className="row align-items-center remember">
								<input type="checkbox" />Remember Me
							</div>
							<div className="form-group">
								<button onClick={this.handleSubmit} className="btn float-right login_btn" > Login</button>
							</div>

						</div>
					</div>
				</div>
			</div>
		)
	}
}

export default Login

